﻿using System;

namespace Algorithm_project
{
    class Node
    {
        public Members Data { get; set; }

        public Node Next { get; set; }

        public Node() { }

        public Node(Members data)
        {
            this.Data = data;
        }
    }
    internal class OrderedLinkedList
    {
        public Node First;
        public Node Last;
        public void Add(Members data)
        {
            Node node = new Node(data);
            if (First == null)
            {
                First = node;
                Last = node;
                return;
            }
            if (node.Data.avg > First.Data.avg)
            {
                node.Next = First;
                First = node;
                return;
            }
            if (node.Data.avg < Last.Data.avg)
            {
                Last.Next = node;
                Last = node;
                return;
            }
            Node move = First.Next;
            Node Previous = First;
            while (move.Data.avg < node.Data.avg)
            {
                Previous = move;
                move = move.Next;
            }
            node.Next = Previous.Next;
            Previous.Next = node;
        }
        public void printMembers()
        {
            Console.Clear();
            Console.WriteLine("All the members in LinkedList");

            for (Node i = First; i != null; i = i.Next)
            {
                i.Data.Print();
            }
            Console.ReadKey();
        }
    }
}
