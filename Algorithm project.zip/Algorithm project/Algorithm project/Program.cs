﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithm_project
{
    internal class Program
    {
        public static int j = 1;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number of The Members",Console.ForegroundColor = ConsoleColor.Blue);
            int n = int.Parse(Console.ReadLine());
            int i = 0;
            OrderedLinkedList linkedList = new OrderedLinkedList();
            while (i < n)
            {
                Members members = new Members();
                linkedList.Add(members);
                i++;j++;
            }
            linkedList.printMembers();
        }
    }
}
