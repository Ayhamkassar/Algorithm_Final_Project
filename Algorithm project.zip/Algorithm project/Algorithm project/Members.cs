﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algorithm_project
{
    internal class Members
    {
        public int Id;
        public string Name { get; set; }
        public int FirstExam { get; set; }
        public int SecondExam { get; set; }
        public enum Mark { F, C, B, A }
        public double avg = 0;

        public Members()
        {
            Id = Program.j;
            Console.WriteLine("Enter the name",Console.ForegroundColor = ConsoleColor.Blue);
            Name = Console.ReadLine();
            Console.WriteLine("Enter the First Exam Mark", Console.ForegroundColor = ConsoleColor.Blue);
            FirstExam = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Second Exam Mark", Console.ForegroundColor = ConsoleColor.Blue);
            SecondExam = int.Parse(Console.ReadLine());
            avg = (FirstExam + SecondExam) / 2;
        }
        public void Print()
        {
            if (avg < 50)
            {
                Console.Write("ID : {0}\tName : {1}\tFirst Exam : {2}\tSecond Exam : {3}\tMark : {4}", Id, Name, FirstExam, SecondExam, Mark.F, Console.ForegroundColor = ConsoleColor.Red);
                Console.WriteLine();
            }
            else if (avg < 70)
            {
                Console.Write("ID : {0}\tName : {1}\tFirst Exam : {2}\tSecond Exam : {3}\tMark : {4}", Id, Name, FirstExam, SecondExam, Mark.C, Console.ForegroundColor = ConsoleColor.Cyan);
                Console.WriteLine();
            }
            else if (avg < 80)
            {
                Console.Write("ID : {0}\tName : {1}\tFirst Exam : {2}\tSecond Exam : {3}\tMark : {4}", Id, Name, FirstExam, SecondExam, Mark.B, Console.ForegroundColor = ConsoleColor.DarkYellow);
                Console.WriteLine();
            }
            else
            {
                Console.Write("ID : {0}\tName : {1}\tFirst Exam : {2}\tSecond Exam : {3}\tMark : {4}", Id, Name, FirstExam, SecondExam, Mark.A, Console.ForegroundColor = ConsoleColor.Green);
                Console.WriteLine();
            }
        }
    }
}
